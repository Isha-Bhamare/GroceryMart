package com.cognizant.OnlineGroceryMart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class OnlineGroceryMartApplication {

	public static void main(String[] args) {

		SpringApplication.run(OnlineGroceryMartApplication.class, args);
	}

}
